﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication6
{
    class Program
    { 
        static void Main(string[] args)
        {

            string path = @"E:\123\Nop.Plugin.Widgets.MenuList";

            string oldPeojectName = "MenuList";
            string newProjectName = "XiaoList";

            string fileExtensions = @".cs,.cshtml,.js,.csproj,.sln,.txt";
            string[] filter = fileExtensions.Split(',');

            RenameAllDir(path, oldPeojectName, newProjectName);
            RenameAllFileNameAndContent(path, oldPeojectName, newProjectName, filter);



            Console.Read();
        }

        #region 递归重命名所有目录

        /// <summary>
        /// 递归重命名所有目录
        /// </summary>
        static void RenameAllDir(string rootDir,string oldPeojectName, string newProjectName)
        {
            string[] allDir = Directory.GetDirectories(rootDir);

            foreach (var item in allDir)
            {
                RenameAllDir(item, oldPeojectName, newProjectName);

                DirectoryInfo dinfo = new DirectoryInfo(item);
                if ( dinfo.Name.Contains(oldPeojectName))
                {
                    var newName = dinfo.Name;

                    newName = newName.Replace(oldPeojectName, newProjectName);

                    var newPath = Path.Combine(dinfo.Parent.FullName, newName);

                    if (dinfo.FullName != newPath)
                    {
                        Console.WriteLine(dinfo.FullName);
                        Console.WriteLine("->");
                        Console.WriteLine(newPath);
                        Console.WriteLine("-------------------------------------------------------------");
                        dinfo.MoveTo(newPath);
                    }

                }
            }
        }

        #endregion

        #region 递归重命名所有文件名和文件内容

        /// <summary>
        /// 递归重命名所有文件名和文件内容
        /// </summary>
        static void RenameAllFileNameAndContent(string rootDir,  string oldPeojectName,  string newProjectName, string[] filter)
        {
            //获取当前目录所有指定文件扩展名的文件
            List<FileInfo> files = new DirectoryInfo(rootDir).GetFiles().Where(m => filter.Any(f => f == m.Extension)).ToList();

            //重命名当前目录文件和文件内容
            foreach (var item in files)
            {

                var text = File.ReadAllText(item.FullName, Encoding.UTF8);
               

                text = text.Replace(oldPeojectName, newProjectName);
                if (item.Name.Contains(oldPeojectName))
                {
                    var newName = item.Name;

                   
                    newName = newName.Replace(oldPeojectName, newProjectName);
                    var newFullName = Path.Combine(item.DirectoryName, newName);
                    File.WriteAllText(newFullName, text, Encoding.UTF8);
                    if (newFullName != item.FullName)
                    {
                        File.Delete(item.FullName);
                    }
                }
                else
                {
                    File.WriteAllText(item.FullName, text, Encoding.UTF8);
                }
                Console.WriteLine(item.Name + " process complete!");

            }

            //获取子目录
            string[] dirs = Directory.GetDirectories(rootDir);
            foreach (var dir in dirs)
            {
                RenameAllFileNameAndContent(dir, oldPeojectName, newProjectName, filter);
            }
        }

        #endregion
    }
}